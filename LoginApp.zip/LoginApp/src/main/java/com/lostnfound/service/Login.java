    
    package com.lostnfound.service;

    import com.lostnfound.model.User; 

    
    public class Login {
        private AuthService authService;
        private User currentUser; 

        public Login(AuthService authService) {
            this.authService = authService;
            this.currentUser = null; 
        }

        
        public boolean performLogin(String identifier, String password) {
            User authenticatedUser = authService.authenticate(identifier, password);
            if (authenticatedUser != null) {
                this.currentUser = authenticatedUser;
                System.out.println("Login successful for: " + authenticatedUser.getName());
                return true;
            } else {
                this.currentUser = null;
                System.out.println("Login failed: Invalid credentials.");
                return false;
            }
        }

        
        public void performLogout() {
            if (currentUser != null) {
                System.out.println("User " + currentUser.getName() + " logged out.");
                this.currentUser = null;
            }
        }

       
        public boolean performRegistration(String name, String email, String matricOrStaffID, String role, String password) {
            // Password sent to AuthService will be hashed there for storage
            User newUser = new User(name, email, matricOrStaffID, role, password); // Password will be hashed by AuthService
            return authService.registerUser(newUser);
        }

        
        public boolean isLoggedIn() {
            return currentUser != null;
        }

        
        public User getCurrentUser() {
            return currentUser;
        }
    }