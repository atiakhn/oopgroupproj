
package com.lostnfound.service;

import com.lostnfound.model.User; 

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;


public class FileBasedAuthService extends AuthService {
    private static final String USER_DATA_FILE = "users.csv";
    private final Path filePath;

    public FileBasedAuthService() {
        this.filePath = Paths.get(USER_DATA_FILE);
        // Ensure the file exists
        if (!Files.exists(filePath)) {
            try {
                Files.createFile(filePath);
                System.out.println("Created user data file: " + USER_DATA_FILE);
            } catch (IOException e) {
                System.err.println("Error creating user data file: " + e.getMessage());
            }
        }
    }

    @Override
    public User authenticate(String identifier, String password) {
        List<User> users = loadUsersFromFile();
        String hashedPassword = hashPassword(password); // Hash the input password for comparison

        Optional<User> authenticatedUser = users.stream()
            .filter(user -> (user.getEmail().equalsIgnoreCase(identifier) ||
                             user.getMatricOrStaffID().equalsIgnoreCase(identifier)) &&
                             user.getPasswordHash().equals(hashedPassword)) // Compare hashed passwords
            .findFirst();

        return authenticatedUser.orElse(null);
    }

    @Override
    public boolean registerUser(User newUser) {
        List<User> users = loadUsersFromFile();

        
        boolean userExists = users.stream()
            .anyMatch(user -> user.getEmail().equalsIgnoreCase(newUser.getEmail()) ||
                             user.getMatricOrStaffID().equalsIgnoreCase(newUser.getMatricOrStaffID()));

        if (userExists) {
            System.out.println("Registration failed: User with email " + newUser.getEmail() + " or ID " + newUser.getMatricOrStaffID() + " already exists.");
            return false;
        }

       
        newUser.setPasswordHash(hashPassword(newUser.getPasswordHash())); // Assuming newUser.getPasswordHash() holds the plain text for registration

        users.add(newUser);
        saveUsersToFile(users);
        System.out.println("User registered successfully: " + newUser.getName());
        return true;
    }

    
    private List<User> loadUsersFromFile() {
        List<User> users = new ArrayList<>();
        if (!Files.exists(filePath)) {
            return users; // Return empty list if file doesn't exist yet
        }
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            users = reader.lines()
                          .map(User::fromCsvString)
                          .collect(Collectors.toList());
        } catch (IOException e) {
            System.err.println("Error loading users from file: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.err.println("Error parsing user data from file: " + e.getMessage());
        }
        return users;
    }

    
    private void saveUsersToFile(List<User> users) {
        try (BufferedWriter writer = Files.newBufferedWriter(filePath)) {
            for (User user : users) {
                writer.write(user.toCsvString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving users to file: " + e.getMessage());
        }
    }

    
    public User findUser(String identifier) {
        return loadUsersFromFile().stream()
                .filter(user -> user.getEmail().equalsIgnoreCase(identifier) ||
                                 user.getMatricOrStaffID().equalsIgnoreCase(identifier))
                .findFirst()
                .orElse(null);
    }
}