
package com.lostnfound.service;

import com.lostnfound.model.User; 


public abstract class AuthService {

    
    public abstract User authenticate(String identifier, String password);

    
    public abstract boolean registerUser(User user);

    
    protected String hashPassword(String password) {
        
        return String.valueOf(password.hashCode());
    }
}