
package com.lostnfound.ui;

import com.lostnfound.model.User; 
import com.lostnfound.service.FileBasedAuthService; 
import com.lostnfound.service.Login; 
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*; 
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class LoginApp extends Application {

    private Login loginService; 
    private Label messageLabel; 
    
    @Override
    public void start(Stage primaryStage) {
        
        FileBasedAuthService authService = new FileBasedAuthService();
        loginService = new Login(authService);

        primaryStage.setTitle("Lost and Found Login System");

        
        GridPane grid = new GridPane();
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10); 
        grid.setVgap(10); 
        grid.setPadding(new Insets(25, 25, 25, 25)); 

        
        Text scenetitle = new Text("Welcome to LostNFound");
        scenetitle.setFont(Font.font("Inter", FontWeight.NORMAL, 20));
        grid.add(scenetitle, 0, 0, 2, 1); 

        
        Label userNameLabel = new Label("Email/ID:");
        grid.add(userNameLabel, 0, 1);

        TextField userTextField = new TextField();
        userTextField.setPromptText("Enter email or staff/matric ID");
        grid.add(userTextField, 1, 1);

        Label pwLabel = new Label("Password:");
        grid.add(pwLabel, 0, 2);

        PasswordField pwBox = new PasswordField();
        pwBox.setPromptText("Enter password");
        grid.add(pwBox, 1, 2);

        Button loginBtn = new Button("Sign In");
        HBox hbBtn = new HBox(10); 
        hbBtn.setAlignment(Pos.BOTTOM_RIGHT);
        hbBtn.getChildren().add(loginBtn);
        grid.add(hbBtn, 1, 3);

        
        messageLabel = new Label();
        messageLabel.setTextFill(Color.RED); 
        grid.add(messageLabel, 0, 4, 2, 1); 

        
        
        Label regNameLabel = new Label("Full Name:");
        TextField regNameField = new TextField();
        regNameField.setPromptText("Enter full name");

        Label regEmailLabel = new Label("Email:");
        TextField regEmailField = new TextField();
        regEmailField.setPromptText("Enter email (for login)");

        Label regIDLabel = new Label("Matric/Staff ID:");
        TextField regIDField = new TextField();
        regIDField.setPromptText("Enter matric or staff ID (for login)");

        Label regRoleLabel = new Label("Role:");
        ComboBox<String> regRoleComboBox = new ComboBox<>();
        regRoleComboBox.getItems().addAll("student", "staff", "admin");
        regRoleComboBox.setPromptText("Select role");

        Label regPwLabel = new Label("Password:");
        PasswordField regPwField = new PasswordField();
        regPwField.setPromptText("Choose a password");

        Button registerBtn = new Button("Register New User");
        Button showRegisterFormBtn = new Button("New User? Register here.");

        
        setRegistrationFieldsVisibility(grid, false, regNameLabel, regNameField, regEmailLabel, regEmailField,
                regIDLabel, regIDField, regRoleLabel, regRoleComboBox, regPwLabel, regPwField, registerBtn);

        
        loginBtn.setOnAction(e -> {
            String identifier = userTextField.getText();
            String password = pwBox.getText();
            if (loginService.performLogin(identifier, password)) {
                messageLabel.setTextFill(Color.GREEN);
                messageLabel.setText("Login Successful! Welcome, " + loginService.getCurrentUser().getName() + "!");
                
                System.out.println("Logged in user: " + loginService.getCurrentUser());
            } else {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Login Failed: Invalid credentials.");
            }
        });

        showRegisterFormBtn.setOnAction(e -> {
            setRegistrationFieldsVisibility(grid, true, regNameLabel, regNameField, regEmailLabel, regEmailField,
                    regIDLabel, regIDField, regRoleLabel, regRoleComboBox, regPwLabel, regPwField, registerBtn);
            
            hbBtn.getChildren().remove(showRegisterFormBtn);
            messageLabel.setText(""); 
        });

        registerBtn.setOnAction(e -> {
            String name = regNameField.getText();
            String email = regEmailField.getText();
            String id = regIDField.getText();
            String role = regRoleComboBox.getValue();
            String password = regPwField.getText();

            if (name.isEmpty() || email.isEmpty() || id.isEmpty() || role == null || password.isEmpty()) {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Please fill all registration fields.");
                return;
            }

            
            if (loginService.performRegistration(name, email, id, role, password)) {
                messageLabel.setTextFill(Color.GREEN);
                messageLabel.setText("Registration Successful! Please sign in.");
               
                regNameField.clear();
                regEmailField.clear();
                regIDField.clear();
                regRoleComboBox.getSelectionModel().clearSelection();
                regPwField.clear();
                setRegistrationFieldsVisibility(grid, false, regNameLabel, regNameField, regEmailLabel, regEmailField,
                        regIDLabel, regIDField, regRoleLabel, regRoleComboBox, regPwLabel, regPwField, registerBtn);
                
                if (!hbBtn.getChildren().contains(showRegisterFormBtn)) {
                    hbBtn.getChildren().add(showRegisterFormBtn);
                }
            } else {
                messageLabel.setTextFill(Color.RED);
                messageLabel.setText("Registration Failed. User might already exist or invalid data.");
            }
        });

        
        hbBtn.getChildren().add(showRegisterFormBtn);


        
        Scene scene = new Scene(grid, 400, 500); 
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    
    private void setRegistrationFieldsVisibility(GridPane grid, boolean visible, Control... elements) {
        

        if (visible) {
            
            grid.add(regNameLabel, 0, 5);
            grid.add(regNameField, 1, 5);
            grid.add(regEmailLabel, 0, 6);
            grid.add(regEmailField, 1, 6);
            grid.add(regIDLabel, 0, 7);
            grid.add(regIDField, 1, 7);
            grid.add(regRoleLabel, 0, 8);
            grid.add(regRoleComboBox, 1, 8);
            grid.add(regPwLabel, 0, 9);
            grid.add(regPwField, 1, 9);
            HBox regBtnBox = new HBox(10);
            regBtnBox.setAlignment(Pos.BOTTOM_RIGHT);
            regBtnBox.getChildren().add(registerBtn);
            grid.add(regBtnBox, 1, 10);
            GridPane.setMargin(regBtnBox, new Insets(10, 0, 0, 0)); 
        } else {
            
            grid.getChildren().remove(regNameLabel);
            grid.getChildren().remove(regNameField);
            grid.getChildren().remove(regEmailLabel);
            grid.getChildren().remove(regEmailField);
            grid.getChildren().remove(regIDLabel);
            grid.getChildren().remove(regIDField);
            grid.getChildren().remove(regRoleLabel);
            grid.getChildren().remove(regRoleComboBox);
            grid.getChildren().remove(regPwLabel);
            grid.getChildren().remove(regPwField);
            
            if (grid.getChildren().contains(registerBtn.getParent())) { 
                grid.getChildren().remove(registerBtn.getParent());
            }
        }
    }

    
    private Label regNameLabel = new Label("Full Name:");
    private TextField regNameField = new TextField();
    private Label regEmailLabel = new Label("Email:");
    private TextField regEmailField = new TextField();
    private Label regIDLabel = new Label("Matric/Staff ID:");
    private TextField regIDField = new TextField();
    private Label regRoleLabel = new Label("Role:");
    private ComboBox<String> regRoleComboBox = new ComboBox<>();
    private Label regPwLabel = new Label("Password:");
    private PasswordField regPwField = new PasswordField();
    private Button registerBtn = new Button("Register New User");


    public static void main(String[] args) {
        launch(args);
    }
}