/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.lostnfound.model;

import java.util.Objects;
import java.util.UUID; 


public class User {
    private String userID; 
    private String name;
    private String email;
    private String matricOrStaffID;
    private String role; 
    private String passwordHash; 

    
    public User(String name, String email, String matricOrStaffID, String role, String passwordHash) {
        this.userID = UUID.randomUUID().toString(); // Generate a unique ID
        this.name = name;
        this.email = email;
        this.matricOrStaffID = matricOrStaffID;
        this.role = role;
        this.passwordHash = passwordHash;
    }

    
    public User(String userID, String name, String email, String matricOrStaffID, String role, String passwordHash) {
        this.userID = userID;
        this.name = name;
        this.email = email;
        this.matricOrStaffID = matricOrStaffID;
        this.role = role;
        this.passwordHash = passwordHash;
    }

    
    public String getUserID() {
        return userID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getMatricOrStaffID() {
        return matricOrStaffID;
    }

    public String getRole() {
        return role;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    
    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMatricOrStaffID(String matricOrStaffID) {
        this.matricOrStaffID = matricOrStaffID;
    }

    public void setRole(String role) {
        this.role = role;
    }

   
    public void setPasswordHash(String newPasswordHash) {
        this.passwordHash = newPasswordHash;
    }

    
    public boolean verifyPassword(String password) {
        
        return String.valueOf(password.hashCode()).equals(this.passwordHash);
    }

    
    public String toCsvString() {
        
        return String.join(",", userID, name, email, matricOrStaffID, role, passwordHash);
    }

    
    public static User fromCsvString(String csvString) {
        String[] parts = csvString.split(",");
        if (parts.length != 6) {
            throw new IllegalArgumentException("Invalid CSV string for User: " + csvString);
        }
        return new User(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
    }

    @Override
    public String toString() {
        return "User{" +
               "userID='" + userID + '\'' +
               ", name='" + name + '\'' +
               ", email='" + email + '\'' +
               ", matricOrStaffID='" + matricOrStaffID + '\'' +
               ", role='" + role + '\'' +
               '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(userID, user.userID);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userID);
    }
}