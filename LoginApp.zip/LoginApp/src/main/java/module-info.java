module com.mycompany.loginapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics; 

    
    exports com.lostnfound.ui;
    
}